Anki Reader - plain WebView wrapper (no ads, no analytics, no libraries).
Only permission: INTERNET.  Your page is at app/src/main/assets/index.html

BUILD OPTION 1 - Android Studio
  1. File > Open > select this folder, let Gradle sync.
  2. Build > Build Bundle(s)/APK(s) > Build APK(s).
  3. APK: app/build/outputs/apk/debug/app-debug.apk  -> copy to phone, install.

BUILD OPTION 2 - GitHub (nothing to install)
  1. Create a new private repo, upload everything in this folder (keep the .github folder).
  2. Actions tab > "Build APK" > Run workflow.
  3. Download the "AnkiReader-apk" artifact from the finished run.

To update the app later, replace assets/index.html and rebuild.
